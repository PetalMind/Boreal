/// <reference path="./.config/sa.d.ts" />

// Damage Blood & Regeneration DE for GTA San Andreas: The Definitive Edition.
// Runtime: CLEO Redux x64 + IniFiles64.
//
// The mod stays on the public CLEO/SA:DE scripting surface. It observes the
// player's real health (and armour, when the public native is available), draws
// a blood overlay through the HUD, and restores health through SET_CHAR_HEALTH
// only after a configurable period without another damage event. It does not
// patch Unreal memory, replace game assets, or make the player invulnerable.

if (typeof HOST === "undefined" || HOST !== "sa_unreal") {
  exit("Damage Blood & Regeneration DE supports only GTA San Andreas: The Definitive Edition.");
}

const PLAYER_ID = 0;
const player = new Player(PLAYER_ID);
const CONFIG_PATH = "./DamageBloodRegenDE.ini";
const CONFIG_VERSION = 1;
const VK_RELOAD = 122; // F11.

const HUD_VIRTUAL_WIDTH = 640;
const HUD_VIRTUAL_HEIGHT = 448;
const DEFAULT_HEALTH_CEILING = 100;

const DEFAULTS = {
  enabled: true,
  bloodEnabled: true,
  regenerationEnabled: true,
  healthCeiling: DEFAULT_HEALTH_CEILING,
  regenerationDelayMs: 5000,
  regenerationPerSecond: 8,
  bloodFadeDelayMs: 2500,
  bloodFadeMs: 12000,
  pulseDurationMs: 460,
  maxStains: 12,
  drawBudget: 64,
  fullScreenAlpha: 28,
  edgeAlpha: 185,
  debug: false,
};

const config = { ...DEFAULTS };
const nativeFailureCounts = new Map();
const optionalNativeState = new Map();
let lastReloadDown = false;
let lastFrameFailureAt = 0;

const BLOOD_COLORS = {
  deep: { r: 57, g: 0, b: 0 },
  dark: { r: 105, g: 0, b: 0 },
  fresh: { r: 170, g: 10, b: 12 },
};

// These are intentionally irregular and asymmetrical. They form a fixed
// screen-space layer behind the event-specific stains, so the overlay still
// communicates low health even when a single hit was too small to add much
// trauma. All coordinates are normalized and converted only at draw time.
const EDGE_STREAKS = [
  { x: 0.08, y: 0.065, w: 0.19, h: 0.020, side: "top" },
  { x: 0.39, y: 0.035, w: 0.12, h: 0.014, side: "top" },
  { x: 0.72, y: 0.080, w: 0.23, h: 0.026, side: "top" },
  { x: 0.025, y: 0.28, w: 0.018, h: 0.23, side: "left" },
  { x: 0.060, y: 0.70, w: 0.028, h: 0.19, side: "left" },
  { x: 0.965, y: 0.20, w: 0.021, h: 0.28, side: "right" },
  { x: 0.925, y: 0.66, w: 0.034, h: 0.22, side: "right" },
  { x: 0.17, y: 0.955, w: 0.26, h: 0.020, side: "bottom" },
  { x: 0.68, y: 0.970, w: 0.18, h: 0.024, side: "bottom" },
];

class DamageBloodModel {
  constructor() {
    this.previousHealth = null;
    this.previousArmour = null;
    this.currentHealth = 0;
    this.currentArmour = 0;
    this.maxHealth = config.healthCeiling;
    this.lastDamageAt = 0;
    this.lastUpdateAt = 0;
    this.lastRegenerationAt = 0;
    this.trauma = 0;
    this.pulse = 0;
    this.regenerationRemainder = 0;
    this.damageCount = 0;
    this.stains = [];
  }

  reset(now) {
    this.previousHealth = null;
    this.previousArmour = null;
    this.currentHealth = 0;
    this.currentArmour = 0;
    this.maxHealth = config.healthCeiling;
    this.lastDamageAt = now;
    this.lastUpdateAt = now;
    this.lastRegenerationAt = now;
    this.trauma = 0;
    this.pulse = 0;
    this.regenerationRemainder = 0;
    this.damageCount = 0;
    this.stains = [];
  }

  observe(sample, now) {
    if (!sample || !Number.isFinite(sample.health) || sample.health <= 0) {
      this.reset(now);
      return false;
    }

    const elapsed = this.lastUpdateAt === 0
      ? 0
      : clamp(now - this.lastUpdateAt, 0, 1000);
    this.lastUpdateAt = now;

    const observedMax = readOptionalMaxHealth(sample.actor);
    if (Number.isFinite(observedMax) && observedMax > 0) {
      this.maxHealth = Math.max(this.maxHealth, observedMax);
    }
    this.maxHealth = Math.max(this.maxHealth, config.healthCeiling, sample.health);

    if (this.previousHealth === null) {
      this.previousHealth = sample.health;
      this.previousArmour = sample.armour;
      this.currentHealth = sample.health;
      this.currentArmour = sample.armour;
      this.lastDamageAt = now;
      return true;
    }

    const healthDrop = Math.max(0, this.previousHealth - sample.health);
    const armourDrop = Number.isFinite(sample.armour) && Number.isFinite(this.previousArmour)
      ? Math.max(0, this.previousArmour - sample.armour)
      : 0;
    if (healthDrop >= 0.5 || armourDrop >= 0.5) {
      this.registerDamage(healthDrop, armourDrop, now);
    }

    this.currentHealth = sample.health;
    this.currentArmour = sample.armour;
    this.previousHealth = sample.health;
    this.previousArmour = sample.armour;
    this.advance(elapsed, now);
    return true;
  }

  registerDamage(healthDrop, armourDrop, now) {
    const healthRatio = healthDrop / Math.max(1, this.maxHealth);
    const armourRatio = armourDrop / 100;
    const traumaGain = clamp(0.16 + healthRatio * 1.10 + armourRatio * 0.16, 0.10, 0.82);
    this.trauma = clamp(this.trauma + traumaGain, 0, 1);
    this.pulse = 1;
    this.lastDamageAt = now;
    this.regenerationRemainder = 0;
    this.damageCount += 1;
    this.stains.push(createStain(this.damageCount, now));
    while (this.stains.length > config.maxStains) this.stains.shift();
  }

  advance(elapsed, now) {
    const seconds = elapsed / 1000;
    if (config.pulseDurationMs > 0) {
      this.pulse = Math.max(0, this.pulse - elapsed / config.pulseDurationMs);
    } else {
      this.pulse = 0;
    }

    if (now - this.lastDamageAt > config.bloodFadeDelayMs && config.bloodFadeMs > 0) {
      this.trauma = Math.max(0, this.trauma - elapsed / config.bloodFadeMs);
    }

    for (const stain of this.stains) stain.ageMs += elapsed;
    this.stains = this.stains.filter(stain => stain.ageMs < config.bloodFadeMs + config.bloodFadeDelayMs);

    if (!Number.isFinite(seconds) || seconds <= 0) return;
  }

  get healthDeficit() {
    if (!Number.isFinite(this.currentHealth) || this.maxHealth <= 0) return 0;
    return clamp((this.maxHealth - this.currentHealth) / this.maxHealth, 0, 1);
  }

  get overlayStrength() {
    // The current health deficit keeps the blood visible after a large hit;
    // trauma covers armour-only hits and gives small hits an immediate pulse.
    return clamp(Math.max(this.healthDeficit * 0.96, this.trauma), 0, 1);
  }

  canRegenerate(now) {
    return config.enabled && config.regenerationEnabled &&
      this.currentHealth > 0 &&
      this.currentHealth < this.maxHealth - 0.01 &&
      now - this.lastDamageAt >= config.regenerationDelayMs;
  }

  regenerate(actor, now) {
    const elapsed = this.lastRegenerationAt === 0
      ? 0
      : clamp(now - this.lastRegenerationAt, 0, 1000);
    this.lastRegenerationAt = now;

    if (!this.canRegenerate(now)) {
      if (this.currentHealth >= this.maxHealth - 0.01) this.regenerationRemainder = 0;
      return;
    }

    this.regenerationRemainder += config.regenerationPerSecond * elapsed / 1000;
    const amount = Math.floor(this.regenerationRemainder);
    if (amount < 1) return;

    this.regenerationRemainder -= amount;
    const targetHealth = Math.min(this.maxHealth, Math.floor(this.currentHealth + amount));
    if (targetHealth <= this.currentHealth) return;

    if (setHealth(actor, targetHealth)) {
      this.currentHealth = targetHealth;
      this.previousHealth = targetHealth;
      if (targetHealth >= this.maxHealth - 0.01) this.regenerationRemainder = 0;
    }
  }
}

class BloodRenderer {
  render(model, now) {
    if (!config.enabled || !config.bloodEnabled) return;
    const strength = model.overlayStrength;
    if (strength <= 0.001 && model.pulse <= 0.001) return;

    let drawCalls = 0;
    const draw = (x, y, width, height, color, alpha) => {
      if (drawCalls >= config.drawBudget) return false;
      const safeAlpha = clamp(Math.round(alpha), 0, 255);
      if (safeAlpha <= 0) return false;
      drawCalls += 1;
      drawHudRect(x, y, width, height, color.r, color.g, color.b, safeAlpha);
      return true;
    };

    // A low-opacity wash makes the screen feel injured without hiding the
    // world. The edge layer and event stains provide the stronger blood read.
    draw(0.5, 0.5, 1, 1, BLOOD_COLORS.deep,
      config.fullScreenAlpha * (0.28 + strength * 0.72));

    if (model.pulse > 0) {
      const pulseWave = 0.55 + Math.sin(now / 58) * 0.45;
      draw(0.5, 0.5, 1, 1, BLOOD_COLORS.fresh,
        model.pulse * pulseWave * 74);
    }

    const edge = 0.014 + strength * 0.115;
    draw(0.5, edge / 2, 1, edge, BLOOD_COLORS.dark, config.edgeAlpha * (0.28 + strength * 0.72));
    draw(0.5, 1 - edge / 2, 1, edge, BLOOD_COLORS.dark, config.edgeAlpha * (0.24 + strength * 0.76));
    draw(edge / 2, 0.5, edge, 1, BLOOD_COLORS.dark, config.edgeAlpha * (0.26 + strength * 0.74));
    draw(1 - edge / 2, 0.5, edge, 1, BLOOD_COLORS.dark, config.edgeAlpha * (0.30 + strength * 0.70));

    for (const streak of EDGE_STREAKS) {
      const sideFactor = streak.side === "top" || streak.side === "bottom" ? 0.86 : 0.92;
      draw(streak.x, streak.y, streak.w, streak.h, BLOOD_COLORS.fresh,
        config.edgeAlpha * strength * sideFactor);
    }

    for (const stain of model.stains) {
      if (drawCalls >= config.drawBudget) break;
      const stainStrength = strength * stainOpacity(stain) * (0.70 + model.pulse * 0.30);
      drawStain(stain, stainStrength, draw);
    }
  }
}

class DamageBloodController {
  constructor() {
    this.model = new DamageBloodModel();
    this.renderer = new BloodRenderer();
  }

  update(now) {
    if (!config.enabled) {
      this.model.reset(now);
      return;
    }

    const actor = getPlayerActor();
    if (!actor) {
      this.model.reset(now);
      return;
    }

    const sample = readPlayerVitals(actor);
    if (!sample || sample.health <= 0) {
      this.model.reset(now);
      return;
    }

    this.model.observe(sample, now);
    this.model.regenerate(actor, now);
    this.renderer.render(this.model, now);
  }
}

loadConfig();
const controller = new DamageBloodController();
log("Damage Blood & Regeneration DE loaded. F11 reloads the INI.");

while (true) {
  wait(0);
  const now = Date.now();

  if (isKeyPressed(VK_RELOAD)) {
    if (!lastReloadDown) {
      loadConfig();
      log("Damage Blood & Regeneration DE configuration reloaded.");
    }
    lastReloadDown = true;
  } else {
    lastReloadDown = false;
  }

  try {
    controller.update(now);
  } catch (error) {
    if (now - lastFrameFailureAt >= 1000) {
      lastFrameFailureAt = now;
      log("Damage Blood & Regeneration DE: frame recovered from error: " + error);
    }
  }
}

function getPlayerActor() {
  try {
    if (!player.isPlaying()) return null;
    const actor = player.getChar();
    if (!actor || safeNative("IS_CHAR_DEAD", actor) === true) return null;
    return actor;
  } catch (_) {
    return null;
  }
}

function readPlayerVitals(actor) {
  const health = Number(safeNative("GET_CHAR_HEALTH", actor));
  if (!Number.isFinite(health)) return null;

  const armourResult = optionalNative("GET_CHAR_ARMOUR", actor);
  const armour = armourResult.ok && Number.isFinite(Number(armourResult.value))
    ? Number(armourResult.value)
    : NaN;
  return { actor, health, armour };
}

function readOptionalMaxHealth(actor) {
  // GET_CHAR_MAX_HEALTH is not part of every SA:DE definition bundle. Use it
  // only when the installed runtime exposes it, then fall back to the observed
  // ceiling. This keeps the script useful without requiring a memory address.
  const result = optionalNative("GET_CHAR_MAX_HEALTH", actor);
  if (!result.ok) return NaN;
  const value = Number(result.value);
  return Number.isFinite(value) && value > 0 ? value : NaN;
}

function setHealth(actor, health) {
  const result = callNative("SET_CHAR_HEALTH", actor, Math.max(1, Math.round(health)));
  return result.ok;
}

function createStain(index, now) {
  const seed = (index * 1103515245 + 12345) >>> 0;
  const edge = seeded(seed, 0, 4);
  const width = 0.045 + seeded(seed, 1, 1000) / 1000 * 0.13;
  const height = 0.045 + seeded(seed, 2, 1000) / 1000 * 0.18;
  const offset = 0.02 + seeded(seed, 3, 1000) / 1000 * 0.16;
  let x = 0.5;
  let y = 0.5;

  if (edge === 0) {
    x = 0.08 + seeded(seed, 4, 840) / 1000;
    y = offset;
  } else if (edge === 1) {
    x = 1 - offset;
    y = 0.08 + seeded(seed, 5, 840) / 1000;
  } else if (edge === 2) {
    x = 0.08 + seeded(seed, 6, 840) / 1000;
    y = 1 - offset;
  } else {
    x = offset;
    y = 0.08 + seeded(seed, 7, 840) / 1000;
  }

  return {
    x: clamp(x, 0.02, 0.98),
    y: clamp(y, 0.02, 0.98),
    width,
    height,
    horizontal: edge === 0 || edge === 2,
    ageMs: 0,
    createdAt: now,
    alpha: 0.72 + seeded(seed, 8, 280) / 1000,
    seed,
  };
}

function drawStain(stain, strength, draw) {
  const alpha = 210 * clamp(strength, 0, 1) * stain.alpha;
  if (alpha <= 0) return;
  const color = strength > 0.58 ? BLOOD_COLORS.fresh : BLOOD_COLORS.dark;
  const branch = 0.30 + seeded(stain.seed, 9, 260) / 1000;

  if (stain.horizontal) {
    draw(stain.x, stain.y, stain.width, stain.height * 0.28, color, alpha);
    draw(stain.x + stain.width * 0.12, stain.y + stain.height * 0.20,
      stain.width * 0.34, stain.height * 0.70, color, alpha * 0.76);
    draw(stain.x + stain.width * 0.61, stain.y + stain.height * 0.12,
      stain.width * 0.16, stain.height * branch, BLOOD_COLORS.deep, alpha * 0.70);
    draw(stain.x + stain.width * 0.27, stain.y + stain.height * 0.45,
      stain.width * 0.10, stain.height * 0.34, BLOOD_COLORS.fresh, alpha * 0.55);
  } else {
    draw(stain.x, stain.y, stain.width * 0.28, stain.height, color, alpha);
    draw(stain.x + stain.width * 0.18, stain.y + stain.height * 0.10,
      stain.width * 0.68, stain.height * 0.32, color, alpha * 0.76);
    draw(stain.x + stain.width * 0.44, stain.y + stain.height * 0.60,
      stain.width * branch, stain.height * 0.16, BLOOD_COLORS.deep, alpha * 0.70);
    draw(stain.x + stain.width * 0.52, stain.y + stain.height * 0.32,
      stain.width * 0.30, stain.height * 0.10, BLOOD_COLORS.fresh, alpha * 0.55);
  }
}

function stainOpacity(stain) {
  const fadeStart = config.bloodFadeDelayMs;
  if (stain.ageMs <= fadeStart) return 1;
  if (config.bloodFadeMs <= 0) return 0;
  return clamp(1 - (stain.ageMs - fadeStart) / config.bloodFadeMs, 0, 1);
}

function seeded(seed, salt, maximum) {
  let value = (seed ^ (salt * 0x9e3779b9)) >>> 0;
  value = (value * 1664525 + 1013904223) >>> 0;
  return value % maximum;
}

function drawHudRect(x, y, width, height, red, green, blue, alpha) {
  const safeX = clamp(Number(x), 0, 1);
  const safeY = clamp(Number(y), 0, 1);
  const safeWidth = Math.max(0.001, Number(width));
  const safeHeight = Math.max(0.001, Number(height));
  const safeAlpha = clamp(Math.round(alpha), 0, 255);
  if (safeAlpha <= 0) return;

  try {
    if (typeof Hud !== "undefined" && Hud && typeof Hud.DrawRect === "function") {
      Hud.DrawRect(
        safeX * HUD_VIRTUAL_WIDTH,
        safeY * HUD_VIRTUAL_HEIGHT,
        safeWidth * HUD_VIRTUAL_WIDTH,
        safeHeight * HUD_VIRTUAL_HEIGHT,
        clamp(Math.round(red), 0, 255),
        clamp(Math.round(green), 0, 255),
        clamp(Math.round(blue), 0, 255),
        safeAlpha
      );
      return;
    }
  } catch (_) {}

  safeNative(
    "DRAW_RECT",
    safeX * HUD_VIRTUAL_WIDTH,
    safeY * HUD_VIRTUAL_HEIGHT,
    safeWidth * HUD_VIRTUAL_WIDTH,
    safeHeight * HUD_VIRTUAL_HEIGHT,
    clamp(Math.round(red), 0, 255),
    clamp(Math.round(green), 0, 255),
    clamp(Math.round(blue), 0, 255),
    safeAlpha
  );
}

function loadConfig() {
  if (typeof IniFile === "undefined" || typeof IniFile.ReadInt !== "function") {
    log("Damage Blood & Regeneration DE: IniFiles64 unavailable; using defaults.");
    return;
  }

  try {
    const version = readConfigInt("meta", "config_version", CONFIG_VERSION);
    if (version !== CONFIG_VERSION) {
      log("Damage Blood & Regeneration DE: unsupported INI version; using defaults.");
      return;
    }

    config.enabled = readConfigBool("mod", "enabled", DEFAULTS.enabled);
    config.bloodEnabled = readConfigBool("blood", "enabled", DEFAULTS.bloodEnabled);
    config.regenerationEnabled = readConfigBool(
      "regeneration",
      "enabled",
      DEFAULTS.regenerationEnabled
    );
    config.healthCeiling = clamp(
      readConfigInt("regeneration", "fallback_health_ceiling", DEFAULTS.healthCeiling),
      50,
      1000
    );
    config.regenerationDelayMs = clamp(
      readConfigInt("regeneration", "delay_ms", DEFAULTS.regenerationDelayMs),
      500,
      120000
    );
    config.regenerationPerSecond = clamp(
      readConfigInt("regeneration", "health_per_second_x10", DEFAULTS.regenerationPerSecond * 10) / 10,
      0.5,
      100
    );
    config.bloodFadeDelayMs = clamp(
      readConfigInt("blood", "fade_delay_ms", DEFAULTS.bloodFadeDelayMs),
      0,
      120000
    );
    config.bloodFadeMs = clamp(
      readConfigInt("blood", "fade_ms", DEFAULTS.bloodFadeMs),
      500,
      120000
    );
    config.pulseDurationMs = clamp(
      readConfigInt("blood", "pulse_duration_ms", DEFAULTS.pulseDurationMs),
      100,
      3000
    );
    config.maxStains = clamp(readConfigInt("blood", "max_stains", DEFAULTS.maxStains), 2, 24);
    config.drawBudget = clamp(readConfigInt("blood", "draw_budget", DEFAULTS.drawBudget), 16, 96);
    config.fullScreenAlpha = clamp(
      readConfigInt("blood", "full_screen_alpha", DEFAULTS.fullScreenAlpha),
      0,
      120
    );
    config.edgeAlpha = clamp(readConfigInt("blood", "edge_alpha", DEFAULTS.edgeAlpha), 0, 255);
    config.debug = readConfigBool("debug", "enabled", DEFAULTS.debug);
  } catch (error) {
    log("Damage Blood & Regeneration DE: configuration load failed; using defaults: " + error);
  }
}

function readConfigInt(section, key, fallback) {
  try {
    const value = Number(IniFile.ReadInt(CONFIG_PATH, section, key));
    return Number.isFinite(value) ? value : fallback;
  } catch (_) {
    return fallback;
  }
}

function readConfigBool(section, key, fallback) {
  return readConfigInt(section, key, fallback ? 1 : 0) !== 0;
}

function optionalNative(name, ...args) {
  const state = optionalNativeState.get(name);
  if (state === "unsupported") return { ok: false, value: null };

  try {
    const value = native(name, ...args);
    optionalNativeState.set(name, "supported");
    return { ok: true, value };
  } catch (error) {
    optionalNativeState.set(name, "unsupported");
    if (config.debug) log("Damage Blood & Regeneration optional native unavailable: " + name + " " + error);
    return { ok: false, value: null };
  }
}

function callNative(name, ...args) {
  try {
    return { ok: true, value: native(name, ...args) };
  } catch (error) {
    const count = (nativeFailureCounts.get(name) || 0) + 1;
    nativeFailureCounts.set(name, count);
    if (config.debug && count === 1) {
      log("Damage Blood & Regeneration native failure: " + name + " " + error);
    }
    return { ok: false, value: null };
  }
}

function safeNative(name, ...args) {
  return callNative(name, ...args).value;
}

function isKeyPressed(keyCode) {
  try {
    if (typeof Pad !== "undefined" && Pad && typeof Pad.IsKeyPressed === "function") {
      return !!Pad.IsKeyPressed(keyCode);
    }
  } catch (_) {}
  return safeNative("IS_KEY_PRESSED", keyCode) === true;
}

function clamp(value, minimum, maximum) {
  const number = Number(value);
  if (!Number.isFinite(number)) return minimum;
  return Math.max(minimum, Math.min(maximum, number));
}
